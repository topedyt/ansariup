package com.example.up_pariksha

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
