import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart'; // ✅ Import dotenv
import 'package:google_fonts/google_fonts.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// Theme Imports
import '../../../../core/theme/theme_provider.dart';
import '../../../../core/theme/clay_kit.dart';
import '../../../../core/theme/mesh_background.dart';

class SubscriptionScreen extends ConsumerStatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  ConsumerState<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends ConsumerState<SubscriptionScreen> {
  late Razorpay _razorpay;
  bool _isLoading = false;

  // 🛡️ SECURITY: Load key from .env file
  // Make sure your .env file has RAZORPAY_KEY_ID=rzp_test_...
  final String _razorpayKey = dotenv.env['RAZORPAY_KEY_ID'] ?? ''; 

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear(); // clears the listeners
    super.dispose();
  }

  void _startPayment() {
    final user = Supabase.instance.client.auth.currentUser;
    
    // Safety check: Cannot pay if not logged in
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please login to subscribe"))
      );
      return;
    }

    if (_razorpayKey.isEmpty) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Payment Error: Key not found in .env"))
      );
      return;
    }

    setState(() => _isLoading = true);
    
    final userEmail = user.email ?? 'student@exam.com';
    const userPhone = '9876543210'; 

    var options = {
      'key': _razorpayKey,
      'amount': 9900, // 9900 paise = ₹99.00
      'name': 'UP Pariksha Pro',
      'description': 'Premium Exam Preparation Pass',
      'retry': {'enabled': true, 'max_count': 1},
      'send_sms_hash': true,
      'prefill': {
        'contact': userPhone, 
        'email': userEmail
      },
      'theme': {
        'color': '#74B9FF' 
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('🔥 Razorpay Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error launching payment: $e"), 
          backgroundColor: Colors.redAccent
        )
      );
      setState(() => _isLoading = false);
    }
  }

  // --- HANDLERS ---
  
  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    // 🟢 SUCCESS: The user paid!
    debugPrint("Payment ID: ${response.paymentId}");
    
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      
      // 🛡️ CRITICAL SECURITY FIX:
      // We call the RPC *without* parameters. 
      // The server (SQL) determines 'who' to upgrade based on the session token.
      await Supabase.instance.client.rpc('enable_pro_mode');

      // 2. Record Transaction
      await Supabase.instance.client.from('payments').insert({
        'user_id': userId,
        'payment_id': response.paymentId,
        'amount': 99.0,
        'status': 'success'
      });

      if (mounted) {
        setState(() => _isLoading = false);
        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        debugPrint("Payment DB Error: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Payment successful, but activation failed: $e"))
        );
        setState(() => _isLoading = false);
      }
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    // 🔴 ERROR: Payment failed or user cancelled
    debugPrint("Error: ${response.code} - ${response.message}");
    setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Payment Failed: ${response.message}"),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    // 🟡 WALLET: User chose an external wallet
    setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
       SnackBar(content: Text("Wallet Selected: ${response.walletName}"))
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF2D3436),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(
          children: [
            Icon(Icons.verified, color: Colors.greenAccent),
            SizedBox(width: 10),
            Text("Welcome to Pro!", style: TextStyle(color: Colors.white)),
          ],
        ),
        content: const Text(
          "Your account has been upgraded successfully. You now have unlimited access.", 
          style: TextStyle(color: Colors.white70)
        ),
        actions: [
          TextButton(
            onPressed: () {
              context.pop(); // Close dialog
              context.go('/'); // Go Home
            },
            child: const Text("Let's Grind", style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = ref.watch(appThemeProvider);
    
    return Scaffold(
      body: MeshBackground(
        theme: theme,
        child: SafeArea(
          child: Column(
            children: [
              // 1. APP BAR
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () => context.pop(),
                      child: ClayContainer(
                        height: 40, width: 40, borderRadius: 20,
                        color: theme.cardColor,
                        parentColor: theme.bgGradient.first,
                        emboss: false,
                        child: Icon(Icons.close, color: theme.subTextColor, size: 20),
                      ),
                    ),
                    Text("PREMIUM PASS", style: TextStyle(color: theme.subTextColor, fontWeight: FontWeight.bold, letterSpacing: 2)),
                    const SizedBox(width: 40), // Balance
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      
                      // 2. HERO ICON (Big Clay Circle)
                      ClayContainer(
                        height: 100, width: 100, borderRadius: 50,
                        color: theme.cardColor,
                        parentColor: theme.bgGradient.first,
                        emboss: false, // Pop out
                        spread: 4,
                        child: const Icon(Icons.workspace_premium_rounded, size: 50, color: Colors.orange),
                      ),
                      const SizedBox(height: 30),

                      // 3. TEXT INFO
                      Text(
                        "Upgrade to Pro",
                        style: GoogleFonts.outfit(
                          fontSize: 32, 
                          fontWeight: FontWeight.w900, 
                          color: theme.textColor
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        "Stop hitting limits. Get unlimited access to all previous year questions and mock tests.",
                        style: TextStyle(color: theme.subTextColor, fontSize: 16, height: 1.5),
                        textAlign: TextAlign.center,
                      ),
                      
                      const SizedBox(height: 40),

                      // 4. PRICING TICKET (Clay Ticket)
                      ClayContainer(
                        width: double.infinity,
                        borderRadius: 30,
                        color: theme.cardColor,
                        parentColor: theme.bgGradient.first,
                        emboss: false,
                        spread: 6, 
                        child: Padding(
                          padding: const EdgeInsets.all(30),
                          child: Column(
                            children: [
                              Text("ANNUAL PASS", style: TextStyle(color: theme.accentColor, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                              const SizedBox(height: 20),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("₹", style: GoogleFonts.outfit(fontSize: 24, fontWeight: FontWeight.bold, color: theme.textColor)),
                                  Text("99", style: GoogleFonts.outfit(fontSize: 70, fontWeight: FontWeight.w900, color: theme.textColor, height: 1)),
                                ],
                              ),
                              Text("one-time payment", style: TextStyle(color: theme.subTextColor, fontSize: 12)),
                              const SizedBox(height: 30),
                              Divider(color: theme.subTextColor.withOpacity(0.1)),
                              const SizedBox(height: 30),
                              
                              // Benefits List
                              _BenefitRow(text: "5000+ PYQ Database", theme: theme),
                              _BenefitRow(text: "Unlock All Chapters", theme: theme),
                              _BenefitRow(text: "Detailed Explanations", theme: theme),
                              _BenefitRow(text: "No Ad Interruptions", theme: theme),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),

                      // 5. UNLOCK BUTTON
                      GestureDetector(
                        onTap: _isLoading ? null : _startPayment,
                        child: ClayContainer(
                          width: double.infinity,
                          height: 70,
                          borderRadius: 24,
                          color: theme.accentColor, 
                          parentColor: theme.bgGradient.first,
                          emboss: _isLoading, // Press inside if loading
                          spread: 4,
                          child: Center(
                            child: _isLoading 
                                ? const CircularProgressIndicator(color: Colors.white)
                                : Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(Icons.lock_open_rounded, color: Colors.white),
                                      const SizedBox(width: 12),
                                      Text(
                                        "UNLOCK NOW", 
                                        style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1)
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.verified_user_outlined, size: 14, color: theme.subTextColor),
                          const SizedBox(width: 6),
                          Text("Secured by Razorpay", style: TextStyle(fontSize: 12, color: theme.subTextColor)),
                        ],
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BenefitRow extends StatelessWidget {
  final String text;
  final dynamic theme;
  const _BenefitRow({required this.text, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), shape: BoxShape.circle),
            child: const Icon(Icons.check, color: Colors.green, size: 16),
          ),
          const SizedBox(width: 16),
          Text(text, style: TextStyle(fontSize: 16, color: theme.textColor, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}